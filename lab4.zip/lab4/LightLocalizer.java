package lab4;

import lejos.hardware.Sound;
import lejos.robotics.SampleProvider;

public class LightLocalizer {
	//constants
	private static final double del = 17.2;//distance from the color sensor to the centre of robot.
	private static final long CORRECTION_PERIOD = 10;
	private double brightnessThreshold = 0.35;
	//variables
	private Navigation navigation;
	private Odometer odo;
	private SampleProvider colorSensor;
	private float[] colorData;	
	private double brightness;		
	private int numberOfGridLines = 0;
	private boolean isBlackLine = false;
	private double thetaYNegative;/*intermediate variables for calculating x, y, theta */
	private double thetaYPositive;/*intermediate variables for calculating x, y, theta */
	private double thetaXNegative;/*intermediate variables for calculating x, y, theta */
	private double thetaXPositive;/*intermediate variables for calculating x, y, theta */
	private double deltaThetaY;   /*intermediate variables for calculating x, y, theta */
	private double deltaThetaX;   /*intermediate variables for calculating x, y, theta */
	private double x, y, theta; //real x,y,theta after localization
	long correctionStart, correctionEnd;
	////////////////////
	
	public LightLocalizer(Odometer odo, SampleProvider colorSensor, float[] colorData, Navigation navigation) {
		this.navigation = navigation;
		this.odo = odo;
		this.colorSensor = colorSensor;
		this.colorData = colorData;
	}
	
	public void doLocalization() {
		
		navigation.rotateForNavigation();
		
		while (navigation.isRotating() == true){
			
			correctionStart = System.currentTimeMillis();
			colorSensor.fetchSample(colorData, 0);
			brightness = colorData[0];
			if (brightness< brightnessThreshold)
			{
				//lightsensor is crossing the grid line
				isBlackLine = true;
				Sound.beep();
				numberOfGridLines ++;
			}
			else 
			{
				isBlackLine = false;
			}
	    
			if (isBlackLine == true){
				switch (numberOfGridLines) {
				case 1:	thetaYNegative = odo.getTheta();								
						break;
				case 2: thetaXPositive = odo.getTheta();				
						break;
				case 3: thetaYPositive = odo.getTheta();
						break;
				case 4: thetaXNegative = odo.getTheta();
						break;
				}
			}
			correctionEnd = System.currentTimeMillis();
			if (correctionEnd - correctionStart < CORRECTION_PERIOD) {
				try {
					Thread.sleep(CORRECTION_PERIOD - (correctionEnd - correctionStart));
				} catch (InterruptedException e) {}
			}
		}
		
		// do trig to compute (0,0) and 0 degrees
		deltaThetaY = thetaYNegative - thetaYPositive;
		deltaThetaX = thetaXPositive - thetaXNegative;
		x = -del*Math.cos(deltaThetaY/2);
		y = -del*Math.cos(deltaThetaX/2);
		theta = deltaThetaY/2 - thetaYNegative - Math.PI/2;
		
		//set odometer position
		odo.setPosition(new double[] {x, y, theta}, new boolean[] {true, true, true});
		
		// travel to (0,0) and turn to 0 degrees
		navigation.run();
	}
}
