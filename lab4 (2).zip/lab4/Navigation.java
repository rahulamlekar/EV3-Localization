package lab4;

import lejos.hardware.motor.EV3LargeRegulatedMotor;

public class Navigation{
	//constants
	private final static double RADIUS_ERR = 1 * Math.PI/180.0, CM_ERR = 0.5;
	private final int FORWARD_SPEED = 100;
	private final int ROTATE_SPEED = 50;
	private final int ACCELERATION = 4000;
	//variables
	private boolean isNavigating = false;
	private double nextX, nextY;
	private Odometer odometer;
	private EV3LargeRegulatedMotor leftMotor, rightMotor;
	public double WB;              // wheel base (cm)
	public double leftWheelRadius; // Wheel radius (cm)
	public double rightWheelRadius;
	///////////////////////////////////////////////////////
	
	// default constructor
	public Navigation (EV3LargeRegulatedMotor leftMotor, EV3LargeRegulatedMotor rightMotor,
			double leftRadius, double rightRadius, double width, Odometer odometer){
		    // set acceleration
			this.odometer = odometer;
			this.leftMotor = leftMotor;
			this.rightMotor = rightMotor;
			this.leftMotor.setAcceleration(ACCELERATION);
			this.rightMotor.setAcceleration(ACCELERATION);			
			this.WB = width;
			this.leftWheelRadius = leftRadius;
			this.rightWheelRadius = rightRadius;			
		}
	//function for Thread.start()
	public void run(){
		// wait 2 seconds
		try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {}
		
		travelTo(0.0, 0.0);
		turnTo(-odometer.getTheta(), true);				
	}
	/*
	 * TravelTo function which takes as arguments the x and y position in cm Will travel to designated position, while
	 * constantly updating it's heading
	 */
	public void setSpeeds(int lSpd, int rSpd) {
		this.leftMotor.setSpeed(lSpd);
		this.rightMotor.setSpeed(rSpd);
		if (lSpd < 0)
			this.leftMotor.backward();
		else
			this.leftMotor.forward();
		if (rSpd < 0)
			this.rightMotor.backward();
		else
			this.rightMotor.forward();
	}
	
	public void travelTo(double x, double y){
		isNavigating = true;
		double minAng;
		while (Math.abs(x - odometer.getX()) > CM_ERR || Math.abs(y - odometer.getY()) > CM_ERR) {
			//get the current position from odometer (x,y,theta)
			double []currentPosition = new double[3];
			boolean [] returnValue = new boolean[] { true, true, true };			
			odometer.getPosition(currentPosition, returnValue);
			//calculate minimal turning angle
			minAng = angleNeedToRotate(currentPosition, x, y);
			//do the rotation 
			turnTo(minAng, false);
			this.setSpeeds(FORWARD_SPEED, FORWARD_SPEED);
		}
		this.setSpeeds(0, 0);
		/*leftMotor.setSpeed(FORWARD_SPEED);
		rightMotor.setSpeed(FORWARD_SPEED);

		leftMotor.rotate(convertDistance(leftWheelRadius, distanceNeedToTravel), true);
		rightMotor.rotate(convertDistance(rightWheelRadius, distanceNeedToTravel), false);*/
		isNavigating = false;
	}
	private void turnTo(double theta, boolean stop){
		isNavigating = true;
		double startAngle = this.odometer.getTheta();
		double error = this.odometer.getTheta() - startAngle;

		while (!(Math.abs(error) < Math.abs(theta) + RADIUS_ERR) || !(Math.abs(error) > Math.abs(theta) - RADIUS_ERR)) {

			error = this.odometer.getTheta() - startAngle;

			if (theta > 0) {
				this.setSpeeds(ROTATE_SPEED, -ROTATE_SPEED);
			}else if (theta < 0){
				this.setSpeeds(-ROTATE_SPEED, ROTATE_SPEED);
			}else {
				return;
			}
		}

		if (stop) {
			this.setSpeeds(0, 0);
		}
		/*leftMotor.setSpeed(ROTATE_SPEED);
		rightMotor.setSpeed(ROTATE_SPEED);
		//if theta > 0 turn clockwise theta radius
		//if theta < 0 turn counterclockwise theta radius
		int angle = convertAngle(leftWheelRadius, WB, Math.toDegrees(theta));
		leftMotor.rotate(angle, true);
		rightMotor.rotate(-angle, false);*/
		isNavigating = false;
	}
	private double angleNeedToRotate(double []currentPosition, double x, double y){
		double deltaX = x - currentPosition[0];
		double deltaY = y - currentPosition[1];
		double angle = 0.0;
		double deltaAngle;
		
		if (deltaX >= 0 && deltaY > 0){
			angle = Math.atan(deltaX/deltaY);
		}else if(deltaX > 0 && deltaY < 0){
			angle = Math.PI + Math.atan(deltaX/deltaY);
		}else if(deltaX < 0 && deltaY < 0){
			angle = -1*Math.PI + Math.atan(deltaX/deltaY);
		}else if(deltaX < 0 && deltaY > 0){
			angle = Math.atan(deltaX/deltaY);
		}
		else if(deltaX<0 && deltaY==0)
		{
			angle = (-(currentPosition[2]+(Math.PI/2)));
			return(angle);
		}
		else if(deltaX>=0 && deltaY==0)
		{
			angle = ((Math.PI/2)-currentPosition[2]);
			return(angle);
		}
		
		//get minimal turning angle
	    deltaAngle = angle - currentPosition[2];
		if((deltaAngle < Math.PI) && (deltaAngle > -1*Math.PI)){
			//if deltaAngle > 0 means turn clockwise deltaAngle radius,
			//if deltaAngle < 0 means turn counterclockwise deltaAngle radius
			return deltaAngle;
		}
		else if (deltaAngle < -1*Math.PI){
			//turn clockwise deltaAngle + 2*Math.PI
			return (deltaAngle + 2*Math.PI); 
		}
		//else if (deltaAngle > Math.PI)
		else {
			//turn counterclockwise deltaAngle - 2*Math.PI
			return (deltaAngle - 2*Math.PI); 
		}		
	}
	//This method returns true if another thread has called travelTo()  or
	//turnTo()  and the method has yet to return; false otherwise.
	public boolean isNavigating (){
		return isNavigating;
	}
	
	private static int convertDistance(double radius, double distance) {
		return (int) ((180.0 * distance) / (Math.PI * radius));
	}

	private static int convertAngle(double radius, double width, double angle) {
		return convertDistance(radius, Math.PI * width * angle / 360.0);
	}
	public void rotateForLocalization(){
		leftMotor.setSpeed(ROTATE_SPEED);
		rightMotor.setSpeed(ROTATE_SPEED);
		leftMotor.rotate(-convertAngle(leftWheelRadius, WB, 360.0), true);
		rightMotor.rotate(convertAngle(rightWheelRadius, WB, 360.0), true);
	}
	public boolean isRotating(){
		return rightMotor.isMoving();
	}
}
