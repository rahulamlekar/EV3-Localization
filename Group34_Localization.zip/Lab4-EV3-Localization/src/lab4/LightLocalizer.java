package lab4;

import lejos.hardware.Sound;
import lejos.robotics.SampleProvider;

public class LightLocalizer {
	//constants
	private static final double del = 15.4;//distance from the color sensor to the centre of robot.
	private static final long SENSORING_PERIOD = 120;
	private double brightnessThreshold = 0.40;
	//variables
	private Navigation navigation;
	private Odometer odo;
	private SampleProvider colorSensor;
	private float[] colorData;	
	private double brightness;		
	private int numberOfGridLines = 0;
	private boolean isBlackLine = false;
	private double thetaYNegative;/*intermediate variables for calculating x, y, theta */
	private double thetaYPositive;/*intermediate variables for calculating x, y, theta */
	private double thetaXNegative;/*intermediate variables for calculating x, y, theta */
	private double thetaXPositive;/*intermediate variables for calculating x, y, theta */
	private double deltaThetaY;   /*intermediate variables for calculating x, y, theta */
	private double deltaThetaX;   /*intermediate variables for calculating x, y, theta */
	private double x, y, theta; //real x,y,theta after localization
	long correctionStart, correctionEnd;
	////////////////////
	
	public LightLocalizer(Odometer odo, SampleProvider colorSensor, float[] colorData, Navigation navigation) {
		this.navigation = navigation;
		this.odo = odo;
		this.colorSensor = colorSensor;
		this.colorData = colorData;
	}
	
	public void doLocalization() {
		
		initialize(); // moves the robot in an ideal position for localization
		
		navigation.rotateForLocalization();
		double angle = 0;
		
		while (navigation.isRotating() == true){
			correctionStart = System.currentTimeMillis();
			colorSensor.fetchSample(colorData, 0);
			brightness = colorData[0];
			if (brightness < brightnessThreshold)
			{
				//get angle from odometer
				angle = odo.getTheta();
				//lightsensor is crossing the grid line
				isBlackLine = true;
				Sound.beep();
				numberOfGridLines = numberOfGridLines + 1;
			}
			else 
			{
				isBlackLine = false;
			}
	    
			if (isBlackLine == true){
				if (numberOfGridLines == 1){ 
					thetaYNegative = angle;								
				}
				else if (numberOfGridLines == 2){
					thetaXPositive = angle;				
				}		
				else if (numberOfGridLines == 3){ 
					thetaYPositive = angle;
				}
				else if (numberOfGridLines == 4){
					thetaXNegative = angle;
				}		
			 }
			
			correctionEnd = System.currentTimeMillis();
			if (correctionEnd - correctionStart < SENSORING_PERIOD) {
				try {
					Thread.sleep(SENSORING_PERIOD - (correctionEnd - correctionStart));
				} catch (InterruptedException e) {}
			}
		}
		
		// do trig to compute (0,0) and 0 degrees
		deltaThetaY = thetaYNegative - thetaYPositive;
		deltaThetaX = thetaXPositive - thetaXNegative;
		x = -1*del*Math.cos(deltaThetaY/2);
		y = -1*del*Math.cos(deltaThetaX/2);
		theta = deltaThetaY/2 - thetaYNegative - Math.PI/2;
		
		//set odometer position
		odo.setPosition(new double[] {x, y, theta}, new boolean[] {true, true, true});
		
		//travel to (0,0) and turn to 0 degrees
	    navigation.run();
	}
private void initialize() {
		
		navigation.setSpeeds(80, 80);
		
		colorSensor.fetchSample(colorData, 0);
		brightness = colorData[0];
		while (brightness > brightnessThreshold)
		{
			correctionStart = System.currentTimeMillis();
			colorSensor.fetchSample(colorData, 0);
			brightness = colorData[0];
			
			correctionEnd = System.currentTimeMillis();
			if (correctionEnd - correctionStart < SENSORING_PERIOD) {
				try {
					Thread.sleep(SENSORING_PERIOD - (correctionEnd - correctionStart));
				} catch (InterruptedException e) {}
			}
		}
		
		navigation.moveForLocalization();
	
		//
		
	}
}
